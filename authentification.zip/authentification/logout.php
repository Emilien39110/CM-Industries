<p>Log out</p>
<form method="post" action="index.php" id="logout">
	<input type="submit" name="logOutButton" value="Se déconnecter">
</form>