<?php

session_start();

include_once("db.php");

include_once("actions.php");

include_once("view.php");