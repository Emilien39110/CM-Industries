<p>Register</p>
<form method="post" action="index.php" id="registerring">
	<li>
		<p>Courriel</p>
		<input type="email" name="register_username">
	</li>

	<li>
		<p>Mot de passe</p>
		<input type="password" name="register_password">
	</li>

	<li>
		<p>Confirmer mot de passe</p>
		<input type="password" name="register_check_password">
	</li>

	<li>
		<input type="submit" name="send" value="Créer mon compte">
	</li>
</form>