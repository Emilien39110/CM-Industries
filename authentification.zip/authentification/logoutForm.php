<p>Log out</p>
<form method="post" action="index.php" id="logout" class="formLogin">
	<input type="submit" name="logOutButton" value="Se déconnecter">
</form>