<?php
$connexion = mysqli_connect("localhost", "l2", "L2", "bernier_info301_tp1");
mysqli_set_charset($connexion, "utf8");