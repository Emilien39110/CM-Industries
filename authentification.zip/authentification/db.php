<?php
$connexion = mysqli_connect("localhost", "l2", "L2", "CMIndustries");
mysqli_set_charset($connexion, "utf8");