<div id="cookies" style="position : fixed">
	<ul>
		<li>
			<h2>Acceptez-vous les cookies ?</h2>
		</li>
		<li>
			<input type="button" name="cookiesAccepted" value="Oui">
		</li>
	</ul>
</div>