<?php

$page = "home";
if (isset($_GET["page"]))
	$page = $_GET["page"];

if (isset($_POST["login_username"])) {
	$sql = "SELECT * FROM `accounts`";
	$result = mysqli_query($connexion, $sql);

	while ($row = mysqli_fetch_assoc($result)) {
		if (($_POST["login_username"] == $row["login"]) and ($_POST["login_password"] == $row["password"])) {
			$_SESSION["user"] = $row["login"];
		}
	}
	
	header("Location: .");
}

?>