<?php

$page = "home";
if (isset($_GET["page"]))
	$page = $_GET["page"];

function logIn($usernameF1_, $passwordF1_) {
	global $connexion;
	$sqlF1 = "SELECT * FROM `accounts`";
	$resultF1 = mysqli_query($connexion, $sqlF1);

	while ($row = mysqli_fetch_assoc($resultF1)) {
		if (($usernameF1_ == $row["login"]) and ($passwordF1_ == $row["password"])) {
			$_SESSION["user"] = $row["login"];
			$_SESSION["admin"] = $row["adminpermissions"];
		}
	}
	
	header("Location: .");
}

if (isset($_POST["login_username"]) && isset($_POST["login_password"])) {
	logIn($_POST["login_username"], $_POST["login_password"]);
}

if (isset($_POST["register_username"]) && isset($_POST["register_password"]) && isset($_POST["register_check_password"])) {

	if ($_POST["register_password"] == $_POST["register_check_password"]) {
		$sql = "SELECT * FROM `accounts`";
		$result = mysqli_query($connexion, $sql);

		$nomPris = False;
		while ($row = mysqli_fetch_assoc($result)) {
			if (($_POST["register_username"] == $row["login"])) {
				$nomPris = True;
			}
		}
		if ($nomPris == False) {
			$sql_ = "insert into accounts (login, password, adminpermissions) values (
			'".$_POST["register_username"]."',
			'".$_POST["register_password"]."', 0)";

			mysqli_query($connexion, $sql_);

			logIn($_POST["register_username"], $_POST["register_password"]);
		}
	}
	header("Location: .");
}

if(isset($_POST['logOutButton'])) {
	unset($_SESSION['user']);
	header("Location: .");
}

?>