CECI EST UN TEST DES FONCTIONNALITES

Ni le code, ni l'organisation, ni l'aperçu ne sont finals.