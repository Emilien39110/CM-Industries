<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<?php
			//$_SESSION["user"] = "John Doe";
			echo var_dump($_SESSION);
			if (isset($_SESSION["user"])) {
				echo "<p>".$_SESSION["user"]."</p>";
				include_once("logOutForm.php");
			}else{
				include_once("loginForm.php");
			}
		?>
	</body>
</html>