<form method="post" action="logOutActions.php" id="loggingOut">
	<input type="submit" name="send" value="Se déconnecter">
</form>