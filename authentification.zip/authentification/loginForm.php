<p>Login</p>
<form method="post" action="index.php" id="loggingIn">
	<li>
		<p>Utilisateur</p>
		<input type="text" name="login_username">
	</li>

	<li>
		<p>Mot de passe</p>
		<input type="password" name="login_password*">
	</li>

	<li>
		<input type="submit" name="send" value="Connexion">
	</li>
</form>